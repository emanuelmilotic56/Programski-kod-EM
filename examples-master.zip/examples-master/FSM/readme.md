Example source code to accompany my video on Finite State Machines.
