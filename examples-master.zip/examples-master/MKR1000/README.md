Example Arduino sketches for MKR1000
