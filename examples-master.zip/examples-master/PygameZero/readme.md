Learning to program by writing a game is a great way to improve your skills. Not only is it fun, but you get an almost instant reward for every line of code your add! Here is an introduction to Pygame Zero, so that you can write a game for Windows, macOS, Linux, and the Raspberry Pi.

https://youtu.be/vrC5UeC6Jiw
