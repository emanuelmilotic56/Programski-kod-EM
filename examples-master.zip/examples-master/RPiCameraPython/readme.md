Here are the Python examples I used in my video https://youtu.be/RPZZZ6FSZuk about accessing the Raspberry Pi Camera from within Python.

Here are some useful links with documentations, examples etc:

https://picamera.readthedocs.io/en/release-1.13/#

https://projects.raspberrypi.org/en/projects/getting-started-with-picamera
