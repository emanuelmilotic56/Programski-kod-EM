# Moved!

__Piccolo OS has moved to its own repository:__

https://github.com/garyexplains/piccolo_os_v1
