Rasperry Pico examples in C and in MicroPython.
